<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Vendors
 *
 * @author senthil
 */
class Gtwo_Homevideo_Block_Adminhtml_Videos extends Mage_Adminhtml_Block_Widget_Grid_Container {

    protected $_addButtonLabel = 'Add Vedio';

    public function __construct() {
        $this->_controller = 'adminhtml_videos';
        $this->_blockGroup = 'gtwo_homevideo';
        $this->_headerText = Mage::helper('homevideo')->__('Videos Management');
        parent::__construct();
    }

    protected function _prepareLayout() {
        $this->setChild('grid', $this->getLayout()->createBlock($this->_blockGroup . '/' . $this->_controller . '_grid', $this->_controller . '.grid')->setSaveParametersInSession(true));
        return parent::_prepareLayout();
    }

}
