<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Gtwo_Homevideo_Block_Adminhtml_Videos_Edit_Form extends Mage_Adminhtml_Block_Widget_Form {

    protected function _prepareForm() {
        if (Mage::getSingleton('adminhtml/session')->getExampleData()) {
            $data = Mage::getSingleton('adminhtml/session')->getExamplelData();
            Mage::getSingleton('adminhtml/session')->getExampleData(null);
        } elseif (Mage::registry('video_data')) {
            $data = Mage::registry('video_data')->getData();
        } else {
            $data = array();
        }

        $form = new Varien_Data_Form(array(
            'id' => 'edit_form',
            'action' => $this->getUrl('*/*/save', array('id' => $this->getRequest()->getParam('id'))),
            'method' => 'post',
            'enctype' => 'multipart/form-data',
        ));

        $form->setUseContainer(true);

        $this->setForm($form);

        $fieldset = $form->addFieldset('video_form', array(
            'legend' => Mage::helper('homevideo')->__('Video Information')
        ));

        $fieldset->addField('video_name', 'text', array(
            'label' => Mage::helper('homevideo')->__('Name'),
            'class' => 'required-entry ',
            'required' => true,
            'name' => 'video_name',
                
        ));
		
		 $fieldset->addField('video_description', 'textarea', array(
            'label' => Mage::helper('homevideo')->__('Description'),
            'required' => false,
            'name' => 'video_description',
                
        ));
		$fieldset->addField('video_starttime', 'text', array(
            'label' => Mage::helper('homevideo')->__('Video Start Time'),
            'class' => 'required-entry ',
            'required' => false,
            'name' => 'video_starttime',
                
        ));
		$fieldset->addField('video_endtime', 'text', array(
            'label' => Mage::helper('homevideo')->__('Video End Time'),
            'class' => 'required-entry ',
            'required' => false,
            'name' => 'video_endtime',
                
        ));
		$fieldset->addField('volume_status', 'select', array(
          'label'     => Mage::helper('homevideo')->__('Volume'),
          'values'    => array(1=>'On',0=>'Off'),
          'name'      => 'volume_status',
		));
		$fieldset->addField('video_file', 'file', array(
		  'label'     => Mage::helper('homevideo')->__('File'),
		  'required'  => false,
		  'note'     => Mage::helper('homevideo')->__('Allowed File Type mp4,mov,m4v,mv4,3gp,flv,avi,wmv file size not more than 200 MB.'),
		  'name'      => 'video_file',
		  $fieldset->addType('file', Mage::getConfig()->getBlockClassName('gtwo_homevideo/adminhtml_videos_edit_renderer_videodelete')),
		)); 
		
		 $fieldset->addField('video_status', 'select', array(
          'label'     => Mage::helper('homevideo')->__('Status'),
          'values'    => array(0=>'Inactive',1=>'Active'),
          'name'      => 'video_status',
		));
        $form->setValues($data);
        return parent::_prepareForm();
    }
    
    private function getCoutryList() {
        $countryList = Mage::getResourceModel('directory/country_collection')
					->loadData()
					->toOptionArray(false);
        $countryCollection = array();
        $countryCollection[" "] ='Select Country';
        foreach($countryList as $_country) {
            $countryCollection[$_country['value']] =  $_country['label'];
        }
        return $countryCollection ;
    }

}
