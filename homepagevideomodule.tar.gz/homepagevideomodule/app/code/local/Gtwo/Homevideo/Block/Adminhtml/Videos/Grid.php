<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Grid
 *
 * @author senthil
 */
class Gtwo_Homevideo_Block_Adminhtml_Videos_Grid extends Mage_Adminhtml_Block_Widget_Grid {

    public function __construct() {

        parent::__construct();
        $this->setId('videosGrid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('ASC');
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection() {
        $collection = Mage::getModel('homevideo/video')->getCollection();
		//echo $collection->getSelect()->__toString(); exit;
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns() {
        
        /*$this->addColumn('video_id', array(
            'header' => Mage::helper('homevideo')->__('#'),
            'align' => 'left',
            'index' => 'video_id',
            'width' => '50px',
        )); */
        
        $this->addColumn('video_name', array(
            'header' => Mage::helper('homevideo')->__('Name'),
            'align' => 'left',
            'index' => 'video_name',
            'width' => '20px',
        ));
		
		$this->addColumn('video_description', array(
            'header' => Mage::helper('homevideo')->__('Description'),
            'align' => 'left',
            'index' => 'video_description',
            'width' => '50px',
        ));

        $this->addColumn('video_status', array(
            'header' => Mage::helper('homevideo')->__('Status'),
            'align' => 'left',
            'index' => 'video_status',
            'type' => 'options',
            'width' => '50px',
            'options' => array(
                '1' => $this->__('Active'),
                '0' => $this->__('Inactive'),
            )
        ));
        return parent::_prepareColumns();
    }

    public function getRowUrl($row) {
        return $this->getUrl('*/*/edit', array('id' => $row->getVideoId()));
    }
}
