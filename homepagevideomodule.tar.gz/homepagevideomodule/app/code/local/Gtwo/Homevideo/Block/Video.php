<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Vendors
 *
 * @author senthil
 */
class Gtwo_Homevideo_Block_Video extends Mage_Core_Block_Template { 

	public function GetVideo() {
		$video_collection = Mage::getModel('homevideo/video')->getCollection()->addFieldToFilter('video_status',1);
		$video_collection->getSelect()->order('video_id DESC')->limit(1);
		return $video_collection;
	}
}
