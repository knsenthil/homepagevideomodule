<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Helper
 *
 * @author senthil
 */
class Gtwo_Homevideo_Helper_Data extends Mage_Core_Helper_Abstract
{
    /*public function updateDirSepereator($path) 
    {
        return str_replace('\\', DS, $path);
    } */
}
