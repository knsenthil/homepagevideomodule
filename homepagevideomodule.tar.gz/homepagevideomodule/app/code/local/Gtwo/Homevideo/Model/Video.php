<?php
class Gtwo_Homevideo_Model_Video extends Mage_Core_Model_Abstract
{
	const UPLOAD_FILE_SIZE = 209715200;
    protected function _construct()
    {
        $this->_init('homevideo/video');
    }
}