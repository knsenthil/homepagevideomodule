<?php


class Gtwo_Homevideo_Adminhtml_VideoController extends Mage_Adminhtml_Controller_action {

    /**
     * Initialize action
     *
     * Here, we set the breadcrumbs and the active menu
     *
     * @return Mage_Adminhtml_Controller_Action
     */
    protected function _initAction() {
        $this->loadLayout()
                // Make the active menu match the menu config nodes (without 'children' inbetween)
                ->_setActiveMenu('homevideo/homevideo')
                ->_title($this->__('Homevideo'))->_title($this->__('Video'));
        return $this;
    }

    public function indexAction() {

        $this->_initAction();
        $this->renderLayout();
    }

    public function newAction() {
        $this->_forward('edit');
    }

    public function editAction() {
        $id = $this->getRequest()->getParam('id', null);
        $model = Mage::getModel('homevideo/video');
        if ($id) {
			
            $model->load((int) $id);
            if ($model->getVideoId()) {
                $data = Mage::getSingleton('adminhtml/session')->getFormData(true);
                if ($data) {
                    $model->setData($data)->setId($id);
                }
            } else {
                Mage::getSingleton('adminhtml/session')->addError(Mage::helper('homevideo')->__('Video does not exist'));
                $this->_redirect('*/*/');
            }
        } 
		/*else {
			echo 'out'; exit;
		} */
        Mage::register('video_data', $model);
        $this->_initAction();
        $this->getLayout()->getBlock('head')->setCanLoadExtJs(true);
        $this->renderLayout();
    }

    public function saveAction() {
        if ($data = $this->getRequest()->getPost()) {
			//echo "<pre>"; print_r($data); 
				
				try {
					//$path = Mage::getBaseDir('media') . DS.'catalog'.DS.'category' ;
					$path = $_SERVER['DOCUMENT_ROOT'] .'/demo/app/magento/emma/media/catalog/category' ;
					//echo "<pre>";print_r($_FILES);
					//print_r($data);echo "</pre>"; //exit;
					//print_r($path);exit;
					if (isset($_FILES['video_file']['name']) && $_FILES['video_file']['name'] != '') {
						
						$uploader = new Varien_File_Uploader('video_file');
						$uploader->setAllowedExtensions(array('mp4')); // or pdf or anything
						//$uploader->setAllowRenameFiles(true);
						if ($_FILES['video_file']['size'] >= Gtwo_Homevideo_Model_Video::UPLOAD_FILE_SIZE ) { // Limit is set to 5 MB 5000000
							Mage::throwException(Mage::helper('retailers')->__('You have exceeded the max file size.'));
						}
						$uploader->setFilesDispersion(false);
						
						$uploader->save($path, $_FILES['video_file']['name']);
						$data['video_file'] = $uploader->getUploadedFileName();
					}
					// Handling delete functonality
					else if((isset($data['video_file']['delete']) && $data['video_file']['delete'] == 1)){
					//else if($data['video_file']['delete'] == 1){
						//echo $path.'/'.$data['video_file']['value']; exit;
						//$data['video_file'] = '';
						unlink($path.'/'.$data['video_file']['value']);
						//unlink('D:/xampp/htdocs/workspace/emma/media/catalog/category/How_to_tie_a_Shoe_Lace_in_1_Second.mp4');
						//unlink('D:\xampp\htdocs\workspace\emma\media\catalog\category\How_to_tie_a_Shoe_Lace_in_1_Second.mp4');
					}
					$id = $this->getRequest()->getParam('id');
					$model = Mage::getModel('homevideo/video');
					//echo "<pre>"; print_r($data);
					if ($id) {
						$model->load($id);
						//echo "<pre>"; print_r($model->toArray());
						//echo $model->getVideoFile();
						//echo $path . DS . $model->getVideoFile(); 
						if (file_exists($path . DS . $model->getVideoFile())) { 
						//echo '====oooo';
							$data['video_file'] = $data['video_file']['value'];
						} else {
							//echo 'onini';
							$data['video_file'] = '';
						}
						
					}
						
					$model->setData($data);
					//echo "<pre>"; print_r($model->toArray());
					//exit;
					Mage::getSingleton('adminhtml/session')->setFormData($data);
					if ($id) {
						$model->setId($id);
					}
					$model->save();

					if (!$model->getId()) {
						Mage::throwException(Mage::helper('homevideo')->__('Error saving Video'));
					}

					Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('homevideo')->__('Video was successfully saved.'));
					Mage::getSingleton('adminhtml/session')->setFormData(false);

					// The following line decides if it is a "save" or "save and continue"
					if ($this->getRequest()->getParam('back')) {
						$this->_redirect('*/*/edit', array('id' => $model->getVideoId()));
					}
					else if((isset($data['video_file']['delete']) && $data['video_file']['delete'] == 1)){
						$this->_redirect('*/*/edit', array('id' => $model->getVideoId()));
					}
					else {
						$this->_redirect('*/*/');
					}
					
				} 
				catch(Exception $e) {
					 Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
					if ($model && $model->getVideoId()) {
						$this->_redirect('*/*/edit', array('id' => $model->getVideoId()));
					} else {
						$this->_redirect('*/*/');
					}
				}
			
			
			return;
        }
		

		
		/*if (!empty( $_FILES['main_image']['name'] )) 
		{
			$data['main_image'] =  $_FILES['main_image']['name'] ;
		} 
		else 
		{
			if (isset($data['main_image']['delete']) && $data['main_image']['delete'] == 1) 
			{
				if ($data['main_image']['value'] != '')
					$this->removeFile($data['main_image']['value']);
				$data['main_image'] = '';
			}
			else 
			{
				unset($data['main_image']);
			}
		}
		else {      
				if(isset($data['video_file']['delete']) && $data['video_file']['delete'] == 1)
					$data['image_main'] = '';
				else
					unset($data['video_file']);
			} */
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('retailers')->__('No data found to save'));
        $this->_redirect('*/*/');
    }
	
	/*public function removeFile($file) 
	{
        $_helper = Mage::helper('homevideo');
        $file = $_helper->updateDirSepereator($file);
        $directory =  Mage::getBaseDir('media') . DS.'catalog'.DS.'category' ;
        $io = new Varien_Io_File();
        $result = $io->rmdir($directory, true);
	} */

    public function deleteAction() {
        if ($id = $this->getRequest()->getParam('id')) {
            try {
                $model = Mage::getModel('homevideo/video');
                $model->setId($id);
                $model->delete();
                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('homevideo')->__('The Video has been deleted.'));
                $this->_redirect('*/*/');
                return;
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                return;
            }
        }
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Unable to find the Video to delete.'));
        $this->_redirect('*/*/');
    }

}
