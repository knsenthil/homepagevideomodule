<?php


class Gtwo_Homevideo_Adminhtml_VideoController extends Mage_Adminhtml_Controller_action {

    /**
     * Initialize action
     *
     * Here, we set the breadcrumbs and the active menu
     *
     * @return Mage_Adminhtml_Controller_Action
     */
    protected function _initAction() {
        $this->loadLayout()
                // Make the active menu match the menu config nodes (without 'children' inbetween)
                ->_setActiveMenu('homevideo/homevideo')
                ->_title($this->__('Homevideo'))->_title($this->__('Video'));
        return $this;
    }

    public function indexAction() {

        $this->_initAction();
        $this->renderLayout();
    }

    public function newAction() {
        $this->_forward('edit');
    }

    public function editAction() {
        $id = $this->getRequest()->getParam('id', null);
        $model = Mage::getModel('homevideo/video');
        if ($id) {
			
            $model->load((int) $id);
            if ($model->getVideoId()) {
                $data = Mage::getSingleton('adminhtml/session')->getFormData(true);
                if ($data) {
                    $model->setData($data)->setId($id);
                }
            } else {
                Mage::getSingleton('adminhtml/session')->addError(Mage::helper('homevideo')->__('Video does not exist'));
                $this->_redirect('*/*/');
            }
        } 
		
        Mage::register('video_data', $model);
        $this->_initAction();
        $this->getLayout()->getBlock('head')->setCanLoadExtJs(true);
        $this->renderLayout();
    }

    public function saveAction() {
        if ($data = $this->getRequest()->getPost()) {
			//echo "<pre>"; print_r($data); exit;
				try {
					//$path = Mage::getBaseDir('media') . DS.'catalog'.DS.'category' ;
					$path = Mage::getBaseDir('media') . DS.'homevideo' ;
					if (isset($_FILES['video_file']['name']) && $_FILES['video_file']['name'] != '') {
						
						$uploader = new Varien_File_Uploader('video_file');
						$uploader->setAllowedExtensions(array('mp4','mov','m4v','mv4','3gp','flv','avi','wmv')); 
						//$uploader->setAllowRenameFiles(true);
						if ($_FILES['video_file']['size'] >= Gtwo_Homevideo_Model_Video::UPLOAD_FILE_SIZE ) { // Limit is set to 200 MB 209715200
							Mage::throwException(Mage::helper('retailers')->__('You have exceeded the max file size.'));
						}
						$uploader->setFilesDispersion(false);
						
						$uploader->save($path, time().$_FILES['video_file']['name']);
						$data['video_file'] = $uploader->getUploadedFileName();
					}
					// Handling delete functonality
					else if((isset($data['video_file']['delete']) && $data['video_file']['delete'] == 1)){
						
						unlink($path.DS.$data['video_file']['value']);
						$data['video_file'] = '';
					}
					
					
					
					$id = $this->getRequest()->getParam('id');
					$model = Mage::getModel('homevideo/video');
					if ($id) {
						$model->load($id);
						if (isset($_FILES['video_file']['name']) && $_FILES['video_file']['name'] != '') {
							$data['video_file'] = $uploader->getUploadedFileName();
							
						} else {
							if (file_exists($path . DS . $model->getVideoFile())) { 
								$data['video_file'] = $data['video_file']['value'];
							} else {
								$data['video_file'] = '';
							}
						} 
					}
					//echo "<pre>"; print_r($data); exit;
		
					$model->setData($data);
					Mage::getSingleton('adminhtml/session')->setFormData($data);
					if ($id) {
						$model->setId($id);
					}
					$model->save();
					if (!$model->getId()) {
						Mage::throwException(Mage::helper('homevideo')->__('Error saving Video'));
					}				
					// inactive all other videos
					if($model->getVideoStatus()==1) {
						$video_collection =  Mage::getModel('homevideo/video')->getCollection()->addFieldToFilter('video_id',array('nin'=>$model->getVideoId()));
						foreach($video_collection as $_video) {
								
							$video = Mage::getModel('homevideo/video')->load($_video->getVideoId());
							
							$video->setVideoStatus(0);
							$video->save(false);	
						}
					}

					Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('homevideo')->__('Video was successfully saved.'));
					Mage::getSingleton('adminhtml/session')->setFormData(false);

					// The following line decides if it is a "save" or "save and continue"
					if ($this->getRequest()->getParam('back')) {
						$this->_redirect('*/*/edit', array('id' => $model->getVideoId()));
					}
					else {
						$this->_redirect('*/*/');
					}
				} 
				catch(Exception $e) {
					 Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
					if ($model && $model->getVideoId()) {
						$this->_redirect('*/*/edit', array('id' => $model->getVideoId()));
					} else {
						$this->_redirect('*/*/');
					}
				}
			
			
			return;
        }
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('retailers')->__('No data found to save'));
        $this->_redirect('*/*/');
    }

    public function deleteAction() {
        if ($id = $this->getRequest()->getParam('id')) {
            try {
				$video = Mage::getModel('homevideo/video')->load($id);
                $model = Mage::getModel('homevideo/video');
                $model->setId($id);
                $model->delete();
				$video_file = $video->getVideoFile();
				
				if(file_exists(Mage::getBaseDir('media') . DS.'homevideo'.DS.$video_file)) {
					unlink(Mage::getBaseDir('media') . DS.'homevideo'.DS.$video_file);
				}
                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('homevideo')->__('The Video has been deleted.'));
                $this->_redirect('*/*/');
                return;
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                return;
            }
        }
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Unable to find the Video to delete.'));
        $this->_redirect('*/*/');
    }

}
