{{block type="gtwo_homevideo/video" name="home_video" template="homevideo/video.phtml"}}
